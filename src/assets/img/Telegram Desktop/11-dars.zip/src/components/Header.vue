<template>
  <header class="header">
    <nav class="header__nav">
      <a href="#">logo</a>
      <ul class="header__list">
        <li>
            <router-link to="/">Home</router-link>
        </li>
        <li>
            <router-link to="/about">About</router-link>
        </li>
      </ul>
    </nav>
  </header>
</template>

<script>
export default {};
</script>
<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  list-style: none;
  text-decoration: none;
}
.header {
  background-color: #333;
  padding: 30px;
}
.header__nav {
  display: flex;
  justify-content: space-around;
}
.header__nav a {
  color: #fff;
  font-size: 30px;
}
.header__list {
  display: flex;
  gap: 30px;
}
</style>