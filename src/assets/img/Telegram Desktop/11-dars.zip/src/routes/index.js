import { createRouter, createWebHistory } from "vue-router";

import Home from "@/pages/Home.vue"
import About from "@/pages/About.vue"

const routers = createRouter({
    history: createWebHistory(),
    routes: [
        { path: '/', name: "HomePage", component: Home },
        { path: '/about', name: "AboutPage", component: About },
        
    ]
})


export default routers;