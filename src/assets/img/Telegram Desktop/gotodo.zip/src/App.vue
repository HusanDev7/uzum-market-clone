<template>
  <Apppage :list="list" @openModal="openModal" />
  <Modal v-show="modalOpen" @closemodal="closemodal" />
</template>

<script>
import Apppage from "@/components/Apppage.vue";
import Modal from "@/components/Modal.vue";

export default {
  data() {
    return {
      modalOpen: false,
      list: [],
    };
  },

  components: {
    Apppage,
    Modal,
  },

  methods: {
    openModal() {
      this.modalOpen = true;
    },

    closemodal() {
      this.modalOpen = false;
    },

    getList() {
      let localList = localStorage.list;
      if (localList) {
        this.list = JSON.parse(localList);
      }
    },
  },

  watch: {
    list: {
      handler() {
        localStorage.list = JSON.stringify(this.list);
      },
      deep: true,
    },
  },

  mounted() {
    this.getList();
  },
};
</script>

<style lang="scss"></style>
