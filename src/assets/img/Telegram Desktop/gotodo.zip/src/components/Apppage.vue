<template>
  <div class="box-app">
    <div class="aside">
      <aside>
        <div class="aside__head">
          <div class="aside__head-mini">
            <img src="@/assets/img/filtr.svg" alt="" />
          </div>
          <div class="aside__head-mini">
            <h3 class="aside__head-h3">Все задачи</h3>
          </div>
        </div>

        <div class="aside__box">
          <div class="aside__box-mini">
            <img src="@/assets/img/1.svg" alt="" />
            <h4 class="aside__box-h4">Покупки</h4>
            <img class="aside__box-img" src="@/assets/img/remove.svg" alt="" />
          </div>

          <div class="aside__box-mini">
            <img src="@/assets/img/2.svg" alt="" />
            <h4 class="aside__box-h4">Фронтенд</h4>
            <img class="aside__box-img" src="@/assets/img/remove.svg" alt="" />
          </div>

          <div class="aside__box-mini">
            <img src="@/assets/img/3.svg" alt="" />
            <h4 class="aside__box-h4">Фильмы</h4>
            <img class="aside__box-img" src="@/assets/img/remove.svg" alt="" />
          </div>

          <div class="aside__box-mini">
            <img src="@/assets/img/4.svg" alt="" />
            <h4 class="aside__box-h4">Книги</h4>
            <img class="aside__box-img" src="@/assets/img/remove.svg" alt="" />
          </div>

          <div class="aside__box-mini">
            <img src="@/assets/img/5.svg" alt="" />
            <h4 class="aside__box-h4">Личное</h4>
            <img class="aside__box-img" src="@/assets/img/remove.svg" alt="" />
          </div>
        </div>

        <button @click="$emit('openModal')" class="plus__task">
          <img src="@/assets/img/plus.svg" alt="" />
          <h5 class="plus-task-h2">Добавить папку</h5>
        </button>
      </aside>
    </div>
    <!-- aside amd Todo List Go -->
    <div class="app-mini">
      <div class="txt__box">
        <h2 class="txt__box-h1">Фронтенд</h2>
        <img class="img-remove-txt" src="@/assets/img/pancl.svg" alt="" />
      </div>

      <div class="linia"></div>

      <ul class="list">
        <transition-group name="addTxt">
          <li v-for="item in list" :key="item.id">
            <label class="checkboxcontainer">
              <input type="checkbox" id="myCheckbox" />
              <span class="checkmark"></span>
            </label>

            <p class="list-p">{{ item.title }}</p>
          </li>
        </transition-group>
      </ul>

      <button class="add-task" @click="modal = !modal">
        <img src="@/assets/img/plus.svg" alt="" />
        <h4 class="add-task-h4">Новая задача</h4>
      </button>

      <transition-group name="inputBox">
        <div class="inp__box" v-if="modal">
          <input
            v-model="newTodo"
            class="input-add"
            type="text"
            placeholder="Текст задачи"
          />

          <div class="btns">
            <button @click="addList" class="add">Добавить задачу</button>
            <button @click="removTxt" class="remove">Отмена</button>
          </div>
        </div>
      </transition-group>
    </div>
  </div>
</template>

<script>
let id = 1;
export default {
  data() {
    return {
      newTodo: "",
      modal: false,
    };
  },

  props: {
    list: {
      typeof: Array,
    },
  },

  methods: {
    addList() {
      if (this.newTodo != 0 || alert("Ustoz qachon end Fudboll oynimz?)) ⚽")) {
        const addTodo = this.list.push({
          id: id++,
          title: this.newTodo,
        });
        this.newTodo = "";
      }
    },

    removTxt() {
      this.newTodo = "";
    },
  },
};
</script>

<style lang="scss"></style>
