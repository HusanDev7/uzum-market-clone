<template>
  <Transition name="animation">
    <div class="select__box">
      <input type="text" placeholder="Название папки" />
      <div class="select__mini">
        <span class="color1"></span>
        <span class="color2"></span>
        <span class="color3"></span>
        <span class="color4"></span>
        <span class="color5"></span>
        <span class="color6"></span>
        <span class="color7"></span>
        <span class="color8"></span>
      </div>

      <button class="btn">Добавить</button>

      <div class="remove">
        <button @click="$emit('closemodal')" class="remove-mini">
          <img src="@/assets/img/remove.svg" alt="" />
        </button>
      </div>
    </div>
  </Transition>
</template>

<script>
export default {};
</script>

<style lang="scss"></style>
