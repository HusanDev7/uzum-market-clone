<script setup>
import HeaderLayouts from "@/layouts/headerLayouts/HeaderLayouts.vue";

</script>
<template>
  <div class="wrapper">
    <HeaderLayouts />
  </div>
</template>