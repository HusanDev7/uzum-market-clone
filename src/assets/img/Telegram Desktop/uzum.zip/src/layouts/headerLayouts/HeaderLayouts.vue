<script setup>
import Navbar from "@/components/navbar/Navbar.vue";
</script>
<template>
  <Navbar />
</template>