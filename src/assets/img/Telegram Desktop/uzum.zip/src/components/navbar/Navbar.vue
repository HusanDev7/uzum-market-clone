<script setup>
import { IconLocation, IconUzbekistan, IconRussian } from "@/lib/imports";
const UzbekistanIcon = IconUzbekistan;
const RussianIcon = IconRussian;
</script>
<template>
  <div class="container">
    <nav class="navbar">
      <div class="navbar__top">
        <div class="navbar__top-item">
          <div class="navbar__top-item-box">
            <span class="navbar__top-icon"><IconLocation /></span>
            <p class="navbar__top-city">Shahar:</p>
            <p class="navbar__top-city-name">Toshkent</p>
            <p class="navbar__top-getZone">Topshirish punktlari</p>
          </div>
        </div>
        <div class="navbar__top-item">
          <div class="navbar__top-item-box">
            <a href="#" class="navbar__top-sallInUzum">Uzumda soting</a>
            <a href="#" class="navbar__top-questions">Savol-Javoblar</a>
            <a href="#" class="navbar__top-questions">Buyurtmalarim</a>
          </div>
        </div>
        <div class="navbar__top-item">
          <select class="navbar__top-language">
            <option value="uz"><UzbekistanIcon /> O'zbekcha</option>
            <option value="ru"><RussianIcon /> Русский</option>
          </select>
        </div>
      </div>
    </nav>
  </div>
</template>