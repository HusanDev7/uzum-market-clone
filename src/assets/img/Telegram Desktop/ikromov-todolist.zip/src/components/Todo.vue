<template>
    <header class="header">
        <div class="header__conteiner">
            <h1 class="header__title">Ikromov</h1>

            <div class="header__task">
                <input v-model="inpText" type="text" placeholder="Add New Task" class="header__input" />
                <input @click="pushTask" type="submit" class="header__input2" title="Add Task" />
            </div>

            <ul class="header__list">
                <li v-for="item in todo2023" :key="item.id" class="header__list-item">
                    <label class="header__list-item-label">
                        
                        <span>{{ item.text }}</span>
                    </label>
                    <span @click="delTask(item)" class="header__delete-btn" title="Delete Task">
                        <img src="@/assets/delete.jpg" alt="" />
                        {{ inpText.addTodo }}
                    </span>
                </li>
            </ul>
        </div>
    </header>
</template>

<script>
let id = 1;
export default {
    data() {
        return {
            inpText: "",
        };
    },

    props: {
        todo2023: {
            typeof: Array,
        },
    },

    methods: {
        pushTask() {
            if (this.inpText != 0) {
                const addTodo = this.todo2023.push({
                    id: id++,
                    text: this.inpText,
                });
                this.inpText = "";
            }
        },
        delTask(item) {
            // const index = this.todo2023.indexOf(item);

            this.todo2023.splice(this.todo2023.indexOf(item), 1)
         

        },
    },
};
</script>

<style></style>
