<template>
    <Todo :todo2023="todo2023" />
</template>

<script>
import Todo from "@/components/Todo.vue";

export default {
    components: {
        Todo,
    },

    data() {
        return {
            todo2023: [],
        };
    },
};
</script>

<style></style>
