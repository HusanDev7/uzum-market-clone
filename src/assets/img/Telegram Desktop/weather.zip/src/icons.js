export const weatherName = {
  "lala": require("@/assets/images2/pasmurno.svg"),
  "ясно": require("@/assets/images2/smallsun.svg"),
  "небольшая облачность": require("@/assets/images2/pasmurno.svg"),
  "smoke": require("@/assets/images2/pasmurno.svg"),
  "облачно с прояснениями": require("@/assets/images2/rain.svg"),
  "небольшой проливной дождь": require("@/assets/images2/rain.svg"),
  "дождь": require("@/assets/images2/rain.svg"),
  "переменная облачность": require("@/assets/images2/smallosadki.svg"),
};
