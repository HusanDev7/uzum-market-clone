<template>
    <div class="main__content">
        <div class="main__content-left">
            <p class="main__content-left-degree">{{ weather.current.temp }}</p>
            <p class="main__content-left-today">Tody: {{ description }}</p>
            <p class="main__content-left-time">Time: {{ getTime }}</p>
            <p class="main__content-left-city">City: {{ weather.name }}</p>

            <div class="main__content-left-img">
                <img :src="getimg" alt="">
            </div>


        </div>
        <div class="main__content-right">

        </div>

    </div>
</template>

<script>
import { mapState } from "vuex"
import { weatherName } from "@/icons"

export default {

    computed: {
        ...mapState(["weather"]),

        description() {
            return this.weather.current.weather[0].description
        },

        getimg() {
            return weatherName[this.description] || weatherName["ясно"]
        },


        getTime() {
            return new Date().toLocaleString("en-US", {
                timeZone: this.weather.timeZone,
                timeStyle: "short",
                hourCycle: "h23",
            })
        }

    }

}
</script>

<style></style>