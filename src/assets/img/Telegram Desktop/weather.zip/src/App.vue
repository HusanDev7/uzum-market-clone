<template>
  <div class="container" v-if="weather">
    <Navbar />
    <Main />
  </div>

  <div v-else>
    <h1>Loading...</h1>
  </div>
</template>

<script>
import { mapState, mapActions } from "vuex"

import Navbar from "./components/Navbar.vue";
import Main from "./components/Main.vue";

export default {

  components: {
    Navbar,
    Main
  },

  computed: {
    ...mapState(["weather"])
  },

  methods: {
    ...mapActions(["getWeather"])
  },

  created() {
    setTimeout(() => {
      this.getWeather("Toshkent")
    }, 500)
  }

}
</script>

<style></style>