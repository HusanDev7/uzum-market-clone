<template>
  <div class="container">
    <nav class="nav">
      <a href="#" class="logo">
        <img src="@/assets/images/logo.svg" alt="">
        <span class="logo__span">vue weather</span>
      </a>
      <div class="nav__search">
        <img src="@/assets/images/kaplya.svg" alt="">
        <input 
        type="text" 
        class="nav__search-input" 
        placeholder="Выбрать город" 
        v-model="city"
        @keydown.enter="getWeather(city)">
      </div>
    </nav>
  </div>
</template>

<script>
import { mapActions, mapGetters, mapMutations, mapState } from "vuex"

export default {
  
  data(){
    return {
      city: ""
    }
  },

  methods: {
    ...mapActions(["getWeather"])
  }
}
</script>

<style></style>