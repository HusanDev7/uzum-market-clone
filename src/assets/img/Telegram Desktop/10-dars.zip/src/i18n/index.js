import uz from './uz.json'
import ru from './ru.json'

export const languages = {
    uz,
    ru
}