<template>
  <div class="container">
    <nav class="nav">
      <a href="#" class="logo">
        <img src="@/assets/images/logo.svg" alt="">
        <span class="logo__span">vue weather</span>
      </a>
      <div class="nav__search">
        <img src="@/assets/images/kaplya.svg" alt="">
        <input type="text" class="nav__search-input" placeholder="Выбрать город">
      </div>
    </nav>
  </div>

</template>

<script>
export default {

}
</script>

<style></style>