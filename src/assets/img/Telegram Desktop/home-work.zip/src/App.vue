<template>
<Todo />
</template>

<script>
import Todo from "@/components/Todo.vue"

export default {
 components: {
  Todo,
 }
}
</script>

<style>

</style>
