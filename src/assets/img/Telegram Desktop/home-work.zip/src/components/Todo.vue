<template>
    <header class="header">
        <div class="header__conteiner" id="tasklist">
            <h1 class="header__title">To Do List (@islomBro)</h1>

            <div class="header__task">
                <input type="text" autocomplete="off" placeholder="Add New Task" class="header__input" v-model="tasks.name" @keyup.enter="newItem">
                <input type="submit" value="" class="header__input2" title="Add Task" @click="newItem.tasks.del">

            </div>


            <ul class="header__list">
                <li class="header__list-item" v-for=" (task, item) in tasks" :key="item.tasks">
                    <label class="header__list-item-label">
                        <input type="checkbox">
                        <span>{{ task.name }}</span>
                    </label>
                    <span class="header__delete-btn" title="Delete Task" @click="delItem(tasks)">{{ task.del }}</span>
                </li>
            </ul>

           
            <span class="header__delete-btn" title="Delete Task" @click="delItem(taskS)">{{ tasks.del }}</span>

        </div>
    </header>
</template>

<script>
export default {
    el: '#tasklist',

    data() {
        return {
            title: 'to dom list',
            tasks: [
               {name: 'Today : Internal Metting'},
               {name: 'Tomorrow : Read a Book'},
               {name: 'Daily : Event Joins'},
               
            ]
            

        }
    },

    methods: {
        newItem () {
            if (!this.tasks.name){
                  return
            }
            this.tasks.push ({
                name: this.tasks.name,
                del: ''
            });
        },
        delItem(task) {
            this.tasks.splice(this.tasks.indexOf(task), 1)
        },
    },
}
</script>

<style></style>