<template>
  <div class="container">
    <div class="box">
      <h2>Todo List</h2>
      <input v-model="inpText" @keydown.enter="addtoTask" type="text" placeholder="Write here ..." />
      <ul class="list">
        <li class="list__li" :class="{ 'active': active }" @click="TogleActive" v-for="item in list" :key="item.id">{{
          item.title }} <i @click="removeText(item)"></i></li>
      </ul>
      <div class="overall-task">Pending Task: <span class="overall-task-progress">0</span></div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      inpText: '',
      active: false,
    }
  },

  props: {
    list: {
      typeof: Array
    }
  },

  methods: {
    addtoTask() {
      if (this.inpText != 0 || alert('Iltmos birinch bolib yozib oling !!! ✒ 🔑')) {
        const addTodo = this.list.push({
          id: new Date().getTime(),
          title: this.inpText
        });
        this.inpText = ''
      }
    },

    removeText(item) {
      const index = this.list.indexOf(item);
      if (index !== -1) {
        this.list.splice(index, 1);
      }
    },

    TogleActive() {
      this.active = !this.active
    },
  },
}
</script>

<style lang="scss"></style>