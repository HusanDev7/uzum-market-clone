<template>
  <div v-if="!loading">
    <Todo :list="list" />
  </div>
  <div v-if="loading">
    <h1> <b>T</b> <b>O</b> <b>D</b> <b>O</b> <b>L</b> <b>I</b> <b>S</b> <b>T</b> <b>...</b></h1>
  </div>
</template>
<script>

import Todo from "@/components/Todo.vue";

export default {

  data() {
    return {
      list: [],
      loading: true
    }
  },

  methods: {
    getList() {
      let localList = localStorage.list;
      if (localList) {
        this.list = JSON.parse(localList);
      }
    },
  },

  // mounted() {

  // },

  components: {
    Todo,
  },

  watch: {
    list: {
      handler() {
        localStorage.list = JSON.stringify(this.list);
      },
      deep: true,
    },
  },

  mounted() {
    setTimeout(() => {
      this.loading = false;
    }, 2000)

    this.getList();
  },

}

</script>
<style lang="scss"></style>

<!-- 
   
 -->