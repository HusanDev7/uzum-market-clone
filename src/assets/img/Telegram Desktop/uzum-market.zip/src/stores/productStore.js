import apiProduct from '@/helpers/api/api'
import { defineStore } from 'pinia'

export const useProductStore = defineStore('product', {
    state: () => ({
        products: null
    }),

    actions: {
        async getProducts() {
            try {
                const res = await apiProduct.getProduct()
                this.products = res.products
            }
            catch (error) {
                console.error(error)
            }
        }
    }
})
