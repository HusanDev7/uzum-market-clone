<script setup>
import Navbar from "@/components/navbar/Navbar.vue";
import Swiper from "@/components/swipper/Swipper.vue";
import Card from "@/components/card/Card.vue";
import { useProductStore } from "@/stores/productStore";
const productStore = useProductStore()
productStore.getProducts()
</script>
<template>
  <Navbar />
  <Swiper />
  <Card v-for="item in productStore.products" :key="item.asin" :card="item" />
</template>
