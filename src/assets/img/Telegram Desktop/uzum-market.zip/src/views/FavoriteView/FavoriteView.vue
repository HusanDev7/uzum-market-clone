<script setup>
</script>
<template>
  <h1>this is Favorite</h1>
</template>