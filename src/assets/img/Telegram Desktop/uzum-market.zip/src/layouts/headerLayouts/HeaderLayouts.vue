<script setup>
import HomePage from '@/pages/HomePage.vue';
</script>
<template>
  <HomePage />
</template>
