<script setup></script>

<template>
    <footer class="footer"></footer>
</template>