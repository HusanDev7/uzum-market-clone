<script setup>
import { IconaddBag, IconHeard, IconStar } from "@/lib/imports";

const props = defineProps({
  card: {
    type: Object,
    required: true
  }
})

</script>
<template>
  <div class="container">
    <div class="card__wrapper">
      <div class="card">
        <!-- <span class="card__heard"><IconHeard /></span>  -->
        <img class="card__img" src="@/assets/img/no-photo.jpg" alt="" />
        <p class="card__title">Lorem, ipsum dolor sit amet consectetur adipisicing elit.</p>
        <p class="card__status">
          <IconStar /> 5.0 (sharhlar)
        </p>
        <div class="card__box">
          <div class="card__box-item">
            <p class="card__salle">3.455 so'm</p>
            <p class="card__price">5.567 so'm</p>
          </div>
          <div class="card__box-item">
            <span class="card__bag">
              <IconaddBag />
            </span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
