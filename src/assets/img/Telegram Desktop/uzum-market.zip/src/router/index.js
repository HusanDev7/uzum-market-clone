import { createRouter, createWebHistory } from 'vue-router';
import HeaderLayouts from '@/layouts/headerLayouts/HeaderLayouts.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      component: HeaderLayouts
    },
    {
      path: '/basket/',
      name: 'basket',
      component: () => import('@/pages/BasketPage.vue')
    },
    {
      path: '/entrance/',
      name: 'entrance',
      component: () => import('@/pages/EnterPage.vue')
    },
    {
      path: '/favorite/',
      name: 'favorite',
      component: () => import('@/pages/FavoritePage.vue')
    }
  ]
})

export default router
