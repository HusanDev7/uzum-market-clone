<script setup>
import FavoriteView from "@/views/FavoriteView/FavoriteView.vue";
</script>
<template>
  <FavoriteView />
</template>