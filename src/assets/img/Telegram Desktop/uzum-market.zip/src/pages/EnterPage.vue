<script setup>
import EnterView from "@/views/EnterView/EnterView.vue";
</script>
<template>
  <EnterView />
</template>