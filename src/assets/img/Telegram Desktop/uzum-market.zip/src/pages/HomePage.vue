<script setup>
import HomeView from '@/views/HomeView/HomeView.vue';
</script>

<template>
    <HomeView />
</template>