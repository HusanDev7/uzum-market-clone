<script setup>
import BasketView from "@/views/BasketView/BasketView.vue";
import { useRoute } from "vue-router";

const router = useRoute();
</script>
<template>
  <BasketView />
</template>