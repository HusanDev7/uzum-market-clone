import axios from 'axios'

const axiosClient = axios.create({
    baseURL: import.meta.env.VITE_API_BASE_URL,
    headers: {
        "X-RapidAPI-Key":
            "024168894emshd15bd1b2f152531p158d6djsn6e00a9ff5df4",
        "X-RapidAPI-Host": "real-time-amazon-data.p.rapidapi.com",
    }
});

axiosClient.interceptors.request.use(async (config) => {
    return config
})

axiosClient.interceptors.response.use((respons) => {
    if (respons && respons.data) {
        return respons.data
    }
    return respons
}, (error) => {
    throw error
})

export default axiosClient