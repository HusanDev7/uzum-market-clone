import axiosClient from "./axiosClient";

const apiProduct = {
    getProduct() {
        const url = 'search?query=Phone';
        return axiosClient.get(url)
    }
}

export default apiProduct