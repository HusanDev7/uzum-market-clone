<script setup>
// import components
import Card from "./components/card/Card.vue";
// import components
</script>

<template>
  <Card />
</template>
