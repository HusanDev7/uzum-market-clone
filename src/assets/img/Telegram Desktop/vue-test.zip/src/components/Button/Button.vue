<script setup>
</script>

<template>
  <button class="btn">Оплатить</button>
</template>
