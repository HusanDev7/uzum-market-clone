<script setup>
// ///////////////////////////////
// imports components code
import Cards from "../cards/Cards.vue";
import IconAdd from "@/components/icons/IconAdd.vue";
// // imports components code

// let usdAmount = "";
// const conversationRub = () => {
//   const usd = parseFloat(usdAmount);
//   if (isNaN(usd)) {
//     return "";
//   }
//   const rub = usd * 75.0;
//   return rub.toFixed(2) + " ₽";
// };

const showModal = () => {
  this.card = !this.card;
};
</script>

<template>
  <div class="card">
    <h2 class="card__title">Пополнить банковской картой</h2>
    <p class="card__txt">Укажите сумму</p>

    <div class="card-conversions">
      <div class="conversions__item">
        <input
          class="convert-inp"
          type="text"
          placeholder="0000.00 $"
          required
        />
      </div>
      <div class="conversions__item">
        <input
          class="convert-inp-two"
          type="text"
          placeholder="0000.00 ₽"
          required
          disabled
        />
      </div>
    </div>

    <button class="card__add-btn">
      <IconAdd />
      <p class="card__add-btn-txt">Новая карта</p>
    </button>
    <Cards />
  </div>
</template>