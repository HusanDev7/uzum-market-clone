<script setup>
import Button from "../Button/Button.vue";
import { ref } from "vue";

// Определяем переменные как ref и возвращаем их из setup()
const bankCardNumber = ref("");
const bankCardMonth = ref("");
const bankCardYers = ref("");
const bankCvvCvc = ref("");

// Метод создания карты

const cards = ref([]);

const bankCardCreate = () => {
  if (
    bankCardNumber.value.length === 16 &&
    bankCardMonth.value.length === 2 &&
    bankCardYers.value.length === 2 &&
    bankCvvCvc.value.length === 3
  ) {
    const newCard = {
      bankCardNumber: bankCardNumber.value,
      bankCardMonth: bankCardMonth.value,
      bankCardYers: bankCardYers.value,
      bankCvvCvc: bankCvvCvc.value,
    };
    cards.value.push(newCard);

    bankCardNumber.value = "";
    bankCardMonth.value = "";
    bankCardYers.value = "";
    bankCvvCvc.value = "";

    console.log("Карта успешно добавлена");
  } else {
    alert("Ошибка: неправильные данные карты");
  }

  console.log(cards.value);
};
</script>

<template>
  <div class="cards__wrapper">
    <div class="cards">
      <div class="cards__item-first">
        <p class="cards__item-first-title">Номер карты</p>
        <input
          v-model="bankCardNumber"
          class="cards__item-first-inp"
          type="text"
          placeholder="Номер карты"
          maxlength="16"
          required
        />
        <p class="cards__item-first-title-date">Действует до</p>

        <div class="cards__item-first-box">
          <div class="cards__item-first-box-item">
            <input
              v-model="bankCardMonth"
              class="item-input"
              type="text"
              placeholder="ММ"
              maxlength="2"
            />
            <span>/</span>
            <input
              v-model="bankCardYers"
              class="item-input"
              type="text"
              placeholder="ГГ"
              maxlength="2"
            />
          </div>
        </div>
      </div>
      <div class="cards__item-next">
        <span class="cards__item-next-line"></span>
        <div class="cards__item-next-box">
          <p class="cards__item-next-cvv-cvc">CVV/CVC</p>
          <input
            v-model="bankCvvCvc"
            type="text"
            placeholder="000"
            maxlength="3"
            required
          />
        </div>
      </div>
    </div>

    <div class="cards__remmber">
      <div class="cards__remmber__item">
        <input class="cards__remmber-agree" type="checkbox" required />
      </div>
      <div class="cards__remmber__item">
        <p class="cards__remmber-title">
          Запомнить эту карту. Это безопасно. <br />
          Сохраняя карту, вы соглашаетесь с
          <span>условиями привязки карты.</span>
        </p>
      </div>
    </div>

    <Button @click="bankCardCreate" />
  </div>

  <div class="newCards" v-for="item in cards" :key="item.bankCardNumber">
    <div class="newCards__item">
      <p class="newCards__item-txt">Номер карты</p>
      <h5 class="newCards__item-num">{{ item.bankCardNumber }}</h5>
      <p class="newCards__item-txt-two">ДЕЙСТВУЕТ ДО</p>
      <div class="newCards__item-box">
        <h5 class="newCards__item-box-item">{{ item.bankCardMonth }}</h5>
        <span class="newCards__item-box-item-line">/</span>
        <h5 class="newCards__item-box-item">{{ item.bankCardYers }}</h5>
      </div>
    </div>
    <div class="newCards__item-two">
      <span class="newCards__item-two-line"></span>
      <div class="newCards__item-two-box">
        <p class="newCards__item-two-txt">CVV/CVC</p>
        <h5 class="newCards__item-two-cvvcvc">{{ item.bankCvvCvc }}</h5>
      </div>
    </div>
  </div>
</template>
