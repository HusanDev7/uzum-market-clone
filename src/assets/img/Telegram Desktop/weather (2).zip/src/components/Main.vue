<template>
    <main class="main">
        <MainContent />
    </main>
</template>

<script>
import MainContent from './MainContent.vue';
export default {
    components: {
        MainContent
    }
}
</script>

<style></style>