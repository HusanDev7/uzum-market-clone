<template>
    <div class="main__content">
        <div class="main__content-left">
            <p class="main__content-left-degree">20°</p>
            <p class="main__content-left-today">Tody:</p>
            <p class="main__content-left-time">Time:</p>
            <p class="main__content-left-city">City:</p>

            <div class="main__content-left-img">
                <img src="@/assets/images/sun.svg" alt="">
            </div>


        </div>
        <div class="main__content-right">

        </div>

    </div>
</template>

<script>
export default {

}
</script>

<style></style>