<template>
  <div class="container">
    <Navbar />
    <Main />
  </div>
</template>

<script>

import Navbar from "./components/Navbar.vue";
import Main from "./components/Main.vue";

export default {

  components: {
    Navbar,
    Main
  },

  data() {
    return {

    }
  },

  methods: {

  }
}
</script>

<style></style>