<template>
  <Header :pages="pages"/>
  <router-view />

</template>

<script>
import Header from "./components/Header.vue";

export default {
  components: {
    Header,
  },

  data() {
    return {
      pages: [
        { name: "Home", url: "/" },
        { name: "Iphone", url: "/about" },
      ],
    };
  },
};
</script>

<style>
</style>