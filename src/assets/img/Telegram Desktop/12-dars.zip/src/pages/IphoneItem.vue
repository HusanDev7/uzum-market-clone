<template>
  <h2>{{ getIphone.title }}</h2>
  <img :src="getIphone.img" alt="" />
  <p>{{ getIphone.info }}</p>
</template>

<script>
import { items } from "@/items";

export default {
  data() {
    return {
      phone: items,
      currentId: null,
    };
  },
  created() {
    this.currentId = this.$route.params.id;
  },

  computed: {
    getIphone() {
      return this.phone.find((element) => {
        return element.id == this.currentId;
      });
    },
  },
};
</script>

<style>
</style>