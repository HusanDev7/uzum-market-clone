<template>
  <div>
    <h1>Iphone</h1>
    <div class="container">
      <div class="cards">
        <div class="card" v-for="item in iphone" :key="item.id">
          <router-link :to="/about/ + item.id">
            <img :src="item.img" alt="" />
          </router-link>
          
          <h3>{{ item.title }}</h3>
          <p>{{ item.info }}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { items } from "@/items";
export default {
  data() {
    return {
      iphone: items,
    };
  },
};
</script>

<style>
.container {
  max-width: 1200px;
  width: 100%;
  margin: 0 auto;
  padding: 0 14px;
}
.cards {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 40px;
}

.card {
  min-height: 300px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  gap: 10px;
}

.card img {
  width: 250px;

}

</style>