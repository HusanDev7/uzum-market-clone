<template>
  <header class="header">
    <nav class="header__nav">
      <router-link to="/">Logo</router-link>
      <ul class="header__list">
        <li v-for="item in pages" :key="item.name">
          <router-link :to="item.url">{{ item.name }}</router-link>
        </li>
      </ul>
    </nav>
  </header>
</template>

<script>
export default {
  props: {
    pages: {
      typeof: Array,
    },
  },
};
</script>
<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  list-style: none;
  text-decoration: none;
}
.header {
  background-color: #333;
  padding: 30px;
}
.header__nav {
  display: flex;
  justify-content: space-around;
}
.header__nav a {
  color: #fff;
  font-size: 30px;
}
.header__list {
  display: flex;
  gap: 30px;
}
</style>