import { createStore } from "vuex";


export const store = createStore({

    state: {
        title: "HELLO VUEX",
        products: ['Damas', 'labo', 'tico'],
        productsNew: null,
    },

    mutations: {
        getProducts(state, payload) {
            state.productsNew = payload
        }
    },
    actions: {
        async getProducts(context) {
            let response = await fetch('https://dummyjson.com/products')
            // console.log(response);
            let result = await response.json();
            // console.log(result.products);
            context.commit("getProducts", result.products)
        }
    },
    getters: {

    },



})


