import { createRouter, createWebHistory } from "vue-router";

import Home from "@/pages/Home.vue"
import About from "@/pages/About.vue"
import IphoneItem from "@/pages/IphoneItem"

const routers = createRouter({
    history: createWebHistory(),
    routes: [
        { path: '/', name: "HomePage", component: Home },
        { path: '/about', name: "AboutPage", component: About },
        { path: "/about/:id", name: "IphoneItemPage", component: IphoneItem }

    ]
})


export default routers;