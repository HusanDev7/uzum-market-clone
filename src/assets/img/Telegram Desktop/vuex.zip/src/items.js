export const items = [
    {
        id: 1,
        img: require("./assets/images/iphone12.jpg"),
        title: "Iphone 12",
        info: "Lorem ipsum dolor sit amet."
    },
    {
        id: 2,
        img: require("./assets/images/iphone15.png"),
        title: "Iphone 15",
        info: "Lorem ipsum dolor sit amet."
    },
    {
        id: 3,
        img: require("./assets/images/iphone6.png"),
        title: "Iphone 6",
        info: "Lorem ipsum dolor sit amet."
    },

]