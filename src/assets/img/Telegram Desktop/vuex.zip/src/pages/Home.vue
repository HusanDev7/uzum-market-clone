<template>
  <h1>Home page</h1>

  <ul>
    <li v-for="(item, i) in products" :key="i">{{ item }}</li>
  </ul>
</template>

<script>
import { mapState, mapActions } from "vuex";
export default {
  computed: {
    ...mapState(["products"]),
  },
  mounted() {
    console.log(this.$store.dispatch("getProducts"));
  },
};
</script>

<style>
</style>